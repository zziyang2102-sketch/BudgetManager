import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BudgetManager {
    private final List<Transaction> transactions = new ArrayList<>();
    private final List<BudgetCategory> categories = new ArrayList<>();

    /**
     * Adds a transaction to the list of transactions.
     *
     * @param transaction The transaction to be added.
     */
    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
    }

    /**
     * Retrieves all transactions.
     *
     * @return A list containing all transactions.
     */
    public List<Transaction> getAllTransactions() {
        return new ArrayList<>(transactions);
    }

    /**
     * Adds a budget category to the list of categories.
     *
     * @param category The budget category to be added.
     * @throws IllegalArgumentException If a category with the same name already exists.
     */
    public void addCategory(BudgetCategory category) {
        if (getCategoryByName(category.getName()) != null) {
            throw new IllegalArgumentException("Category [" + category.getName() + "] already exists");
        }
        categories.add(category);
    }

    /**
     * Removes a budget category by its name.
     *
     * @param categoryName The name of the category to be removed.
     * @throws IllegalArgumentException If the category is not found.
     */
    public void removeCategory(String categoryName) {
        BudgetCategory target = getCategoryByName(categoryName);
        if (target == null) {
            throw new IllegalArgumentException("Category [" + categoryName + "] not found");
        }
        categories.remove(target);
    }

    /**
     * Retrieves a budget category by its name.
     *
     * @param name The name of the category to retrieve.
     * @return The budget category if found, otherwise null.
     */
    public BudgetCategory getCategoryByName(String name) {
        return categories.stream()
                .filter(c -> c.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    /**
     * Retrieves all budget categories.
     *
     * @return A list containing all budget categories.
     */
    public List<BudgetCategory> getAllCategories() {
        return new ArrayList<>(categories);
    }

    /**
     * Retrieves expenses belonging to a specific category.
     *
     * @param categoryName The name of the category to filter expenses by.
     * @return A list of expenses belonging to the specified category.
     */
    public List<Expense> getExpensesByCategory(String categoryName) {
        return transactions.stream()
                .filter(t -> t instanceof Expense)
                .map(t -> (Expense) t)
                .filter(e -> e.getCategory().equalsIgnoreCase(categoryName))
                .collect(Collectors.toList());
    }

    /**
     * Retrieves expenses with an amount greater than a specified threshold.
     *
     * @param threshold The threshold amount to filter expenses by.
     * @return A list of expenses with an absolute amount greater than the threshold.
     */
    public List<Expense> getExpensesAboveAmount(double threshold) {
        return transactions.stream()
                .filter(t -> t instanceof Expense)
                .map(t -> (Expense) t)
                .filter(e -> Math.abs(e.getEffectiveAmount()) > threshold)
                .collect(Collectors.toList());
    }

    /**
     * Retrieves transactions within a specified date range.
     *
     * @param startDate The start date of the range (inclusive).
     * @param endDate   The end date of the range (inclusive).
     * @return A sorted list of transactions within the specified date range.
     */
    public List<Transaction> getTransactionsBetweenDates(String startDate, String endDate) {
        return transactions.stream()
                .filter(t -> t.getDate().compareTo(startDate) >= 0 &&
                        t.getDate().compareTo(endDate) <= 0)
                .sorted((t1, t2) -> t1.getDate().compareTo(t2.getDate()))
                .collect(Collectors.toList());
    }

    /**
     * Calculates the total income from all transactions.
     *
     * @return The sum of all income amounts.
     */
    public double calculateTotalIncome() {
        return transactions.stream()
                .filter(t -> t instanceof Income)
                .mapToDouble(Transaction::getEffectiveAmount)
                .sum();
    }

    /**
     * Calculates the total expenditure from all transactions.
     *
     * @return The sum of all expenditure amounts.
     */
    public double calculateTotalExpenditure() {
        return transactions.stream()
                .filter(t -> t instanceof Expense)
                .mapToDouble(Transaction::getEffectiveAmount)
                .sum();
    }
}