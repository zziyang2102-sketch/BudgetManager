import java.util.UUID;

abstract class Transaction {
    private UUID id;
    private String date;
    private double amount;

    public Transaction(double amount, String date) {
        this.id = UUID.randomUUID();
        this.date = date;
        this.amount = amount;
    }

    public UUID getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }

    public abstract double getEffectiveAmount();
}

class Income extends Transaction {
    private String source;

    public Income(double amount, String date, String source) {
        super(amount, date);
        this.source = source;
    }

    public String getSource() {
        return source;
    }

    @Override
    public double getEffectiveAmount() {
        return getAmount(); 
    }

    @Override
    public String toString() {
        return super.getDate() + " - " + getAmount() + "     INCOME      " + source;
    }
}


class Expense extends Transaction {
    private String paymentMethod;
    private String category;  

    private static final double CASH_FEE = 0;
    private static final double CARD_FEE = 0.01;
    private static final double ALIPAY_WC_FEE = 0.005;
    private static final double ALIPAY_AL_FEE = 0.005;

    public Expense(double amount, String date, String paymentMethod, String category) {
        super(amount, date);
        this.paymentMethod = paymentMethod;
        this.category = category;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public double getEffectiveAmount() {
        double fee = 0;
        switch (paymentMethod.toLowerCase()) {
            case "cash":
                paymentMethod = paymentMethod+"cash payment";
                fee = CASH_FEE;
                break;
            case "card":
                paymentMethod = paymentMethod+"card payment";
                fee = CARD_FEE;
                break;
            case "alipay":
                fee = ALIPAY_AL_FEE;
                paymentMethod = paymentMethod+"alipay payment";
                break;
            case "wechat":
                fee = ALIPAY_WC_FEE;
                paymentMethod = paymentMethod+"wechat payment";
                break;
        }
        return getAmount() * (1 - fee); 
    }

    @Override
    public String toString() {
        double effectiveAmount = getEffectiveAmount();
        return super.getDate() + " - " + effectiveAmount + "     " + category + "      " + paymentMethod;
    }
}

