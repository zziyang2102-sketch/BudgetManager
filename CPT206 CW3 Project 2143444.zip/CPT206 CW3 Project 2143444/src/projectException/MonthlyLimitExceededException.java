package projectException;

public class MonthlyLimitExceededException extends Exception {
    public MonthlyLimitExceededException(String message) {
        super(message);
    }
}
