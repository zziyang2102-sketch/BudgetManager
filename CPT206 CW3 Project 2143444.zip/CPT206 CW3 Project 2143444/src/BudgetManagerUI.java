import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class BudgetManagerUI {
    private static final Scanner scanner = new Scanner(System.in);
    private static final BudgetManager manager = new BudgetManager();
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static void main(String[] args) {
        initializeDefaultCategories();

        String separator = repeatChar('=', 60);
        String spaceLine = repeatChar(' ', 5);

       
        System.out.println("\n\n" + separator);
        System.out.println(spaceLine + " Welcome to Advanced Budget Management System " + spaceLine);
        System.out.println(spaceLine + "Effortlessly organize your finances with our intuitive system" + spaceLine);
        System.out.println(separator + "\n");

        mainMenuLoop();
    }

    private static String repeatChar(char c, int times) {
        if (times <= 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times; i++) {
            sb.append(c);
        }
        return sb.toString();
    }

    private static void initializeDefaultCategories() {
        try {
            manager.addCategory(new BudgetCategory("Food", 500.0));
            manager.addCategory(new BudgetCategory("Transportation", 300.0));
            manager.addCategory(new BudgetCategory("Entertainment", 200.0));
        } catch (IllegalArgumentException e) {
            System.out.println("Error initializing categories: " + e.getMessage());
        }
    }

    private static void mainMenuLoop() {
        while (true) {
            displayMainMenu();
            int choice = getIntInput("Enter your choice (1-6): ", 1, 6);

            switch (choice) {
                case 1:
                    handleIncomeEntry();
                    break;
                case 2:
                    handleExpenseEntry();
                    break;
                case 3:
                    manageBudgetCategories();
                    break;
                case 4:
                    generateReports();
                    break;
                case 5:
                    showFinancialStatistics();
                    break;
                case 6:
                    exitSystem();
                    return;
            }
        }
    }

    private static void displayMainMenu() {
        String separator = repeatChar('=', 60);
        System.out.println("\n" + separator);
        System.out.println("         BUDGET MANAGER SYSTEM MENU         ");
        System.out.println(separator);
        System.out.println("1.  Record Income");
        System.out.println("2.  Record Expense");
        System.out.println("3.  Manage Budget Categories");
        System.out.println("4.  Generate Financial Reports");
        System.out.println("5.  View Financial Statistics");
        System.out.println("6.  Exit System");
        System.out.println(separator);
    }

   
    private static int getIntInput(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                int input = scanner.nextInt();
                scanner.nextLine(); 
                if (input >= min && input <= max) return input;
                System.out.printf("Please enter a number between %d and %d.%n", min, max);
            } else {
                scanner.nextLine(); 
                System.out.println("Invalid input. Please enter an integer.");
            }
        }
    }

    private static double getDoubleInput(String prompt, double min) {
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextDouble()) {
                double input = scanner.nextDouble();
                scanner.nextLine();
                if (input > min) return input;
                System.out.printf("Please enter a number greater than %.2f.%n", min);
            } else {
                scanner.nextLine(); 
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    private static String getNonEmptyInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) return input;
            System.out.println("Input cannot be empty. Please try again.");
        }
    }

    private static String getValidDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String dateStr = scanner.nextLine().trim();
            try {
                LocalDate.parse(dateStr, DATE_FORMAT);
                return dateStr;
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please use yyyy-MM-dd.");
            }
        }
    }

    private static String getPaymentMethod() {
        System.out.println("\nSelect payment method:");
        System.out.println("1. Cash");
        System.out.println("2. Credit Card");
        System.out.println("3. Alipay");
        System.out.println("4. Wechat Pay");
        int choice = getIntInput("Enter option (1-4): ", 1, 4);
        switch (choice) {
            case 1: return "Cash";
            case 2: return "Credit Card";
            case 3: return "Alipay";
            case 4: return "Wechat Pay";
            default: throw new IllegalArgumentException("Invalid payment method choice");
        }
    }

   
    private static void handleIncomeEntry() {
        System.out.println("\n=== ADD INCOME ===");
        double amount = getDoubleInput("Enter income amount ($): ", 0);
        String date = getValidDate("Enter income date (yyyy-MM-dd): ");
        String source = getNonEmptyInput("Enter income source (e.g., Salary): ");

        Income income = new Income(amount, date, source);
        manager.addTransaction(income);
        System.out.printf("Income added successfully! ID: %s%n", income.getId());
    }

    private static void handleExpenseEntry() {
        System.out.println("\n=== ADD EXPENSE ===");
        double amount = getDoubleInput("Enter expense amount ($): ", 0);
        String date = getValidDate("Enter expense date (yyyy-MM-dd): ");
        String paymentMethod = getPaymentMethod();
        String category = selectExistingCategory();

        try {
            Expense expense = new Expense(amount, date, paymentMethod, category);
            BudgetCategory budgetCategory = manager.getCategoryByName(category);
            if (budgetCategory == null) {
                System.out.println("Error: Category not found.");
                return;
            }
            budgetCategory.addExpense(expense.getEffectiveAmount());
            manager.addTransaction(expense);
            System.out.printf("Expense added! Effective amount: $%.2f%n",
                    -expense.getEffectiveAmount());
        } catch (MonthlyLimitExceededException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static String selectExistingCategory() {
        List<BudgetCategory> categories = manager.getAllCategories();
        if (categories.isEmpty()) {
            System.out.println("No categories available. Please add a category first.");
            return null;
        }

        System.out.println("\nAvailable Categories:");
        for (int i = 0; i < categories.size(); i++) {
            BudgetCategory cat = categories.get(i);
            System.out.printf("%d. %s (Limit: $%.2f, Used: $%.2f)%n",
                    i+1, cat.getName(), cat.getMonthlyLimit(), cat.getCurrentExpenditure());
        }
        int choice = getIntInput("Select category (1-" + categories.size() + "): ",
                1, categories.size());
        return categories.get(choice-1).getName();
    }

    private static void manageBudgetCategories() {
        while (true) {
            System.out.println("\n=== BUDGET CATEGORY MANAGEMENT ===");
            System.out.println("1. View All Categories");
            System.out.println("2. Add New Category");
            System.out.println("3. Delete Existing Category");
            System.out.println("4. Reset Category Expenditure");
            System.out.println("5. Return to Main Menu");
            int choice = getIntInput("Enter option (1-5): ", 1, 5);

            if (choice == 5) break;
            switch (choice) {
                case 1:
                    viewAllCategories();
                    break;
                case 2:
                    addNewCategory();
                    break;
                case 3:
                    deleteCategory();
                    break;
                case 4:
                    resetCategoryExpenditure();
                    break;
            }
        }
    }

    private static void viewAllCategories() {
        System.out.println("\n=== ALL BUDGET CATEGORIES ===");
        List<BudgetCategory> categories = manager.getAllCategories();
        if (categories.isEmpty()) {
            System.out.println("No categories found.");
            return;
        }
        System.out.println("Name\t\tMonthly Limit\tCurrent Expenditure");
        System.out.println("-----------------------------------------------------");
        categories.forEach(c -> System.out.printf("%-15s $%-15.2f $%-15.2f%n",
                c.getName(), c.getMonthlyLimit(), c.getCurrentExpenditure()));
    }

    private static void addNewCategory() {
        String name = getNonEmptyInput("Enter new category name: ");
        double limit = getDoubleInput("Enter monthly limit ($): ", 0);
        try {
            manager.addCategory(new BudgetCategory(name, limit));
            System.out.println("Category [" + name + "] added successfully!");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteCategory() {
        String category = selectExistingCategory();
        if (category == null) return;
        try {
            manager.removeCategory(category);
            System.out.println("Category [" + category + "] deleted successfully!");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void resetCategoryExpenditure() {
        String category = selectExistingCategory();
        if (category == null) return;
        BudgetCategory target = manager.getCategoryByName(category);
        if (target != null) {
            target.resetExpenditure();
            System.out.println("Expenditure for [" + category + "] reset to $0.00");
        }
    }

    private static void generateReports() {
        while (true) {
            System.out.println("\n=== REPORT GENERATION ===");
            System.out.println("1. Category Expense Details");
            System.out.println("2. Expenses Above Threshold");
            System.out.println("3. Transactions in Date Range");
            System.out.println("4. Return to Main Menu");
            int choice = getIntInput("Enter option (1-4): ", 1, 4);

            if (choice == 4) break;
            switch (choice) {
                case 1:
                    generateCategoryExpenseReport();
                    break;
                case 2:
                    generateExcessiveExpensesReport();
                    break;
                case 3:
                    generateDateRangeReport();
                    break;
            }
        }
    }

    private static void generateCategoryExpenseReport() {
        String category = selectExistingCategory();
        if (category == null) return;
        List<Expense> expenses = manager.getExpensesByCategory(category);

        System.out.println("\n=== EXPENSE REPORT FOR " + category.toUpperCase() + " ===");
        if (expenses.isEmpty()) {
            System.out.println("No expenses found for this category.");
            return;
        }
        System.out.println("ID\t\tDate\t\tPayment Method\tAmount");
        System.out.println("-----------------------------------------------------------");
        expenses.forEach(e -> System.out.printf("%-36s %-10s %-15s $%.2f%n",
                e.getId(), e.getDate(), e.getPaymentMethod(), -e.getEffectiveAmount()));
    }

    private static void generateExcessiveExpensesReport() {
        double threshold = getDoubleInput("Enter expense threshold ($): ", 0);
        List<Expense> expenses = manager.getExpensesAboveAmount(threshold);

        System.out.println("\n=== EXPENSES ABOVE $" + threshold + " ===");
        if (expenses.isEmpty()) {
            System.out.println("No expenses found above this threshold.");
            return;
        }
        System.out.println("ID\t\tDate\t\tCategory\tAmount");
        System.out.println("-----------------------------------------------------------");
        expenses.forEach(e -> System.out.printf("%-36s %-10s %-15s $%.2f%n",
                e.getId(), e.getDate(), e.getCategory(), -e.getEffectiveAmount()));
    }

    private static void generateDateRangeReport() {
        String startDate = getValidDate("Enter start date (yyyy-MM-dd): ");
        String endDate = getValidDate("Enter end date (yyyy-MM-dd): ");
        List<Transaction> transactions = manager.getTransactionsBetweenDates(startDate, endDate);

        System.out.println("\n=== TRANSACTIONS BETWEEN " + startDate + " AND " + endDate + " ===");
        if (transactions.isEmpty()) {
            System.out.println("No transactions found in this date range.");
            return;
        }
        System.out.println("ID\t\tDate\t\tType\t\tAmount");
        System.out.println("-----------------------------------------------------------");
        transactions.forEach(t -> {
            String type = t instanceof Income ? "Income" : "Expense";
            System.out.printf("%-36s %-10s %-15s $%.2f%n",
                    t.getId(), t.getDate(), type, t.getEffectiveAmount());
        });
    }

    private static void showFinancialStatistics() {
        double totalIncome = manager.calculateTotalIncome();
        double totalExpense = manager.calculateTotalExpenditure();
        double netBalance = totalIncome + totalExpense;

        System.out.println("\n=== FINANCIAL STATISTICS ===");
        System.out.printf("Total Income: $%.2f%n", totalIncome);
        System.out.printf("Total Expenditure: $%.2f%n", -totalExpense); 
        System.out.printf("Net Balance: $%.2f%n", netBalance);

        System.out.println("\n=== CATEGORY UTILIZATION ===");
        List<BudgetCategory> categories = manager.getAllCategories();
        categories.forEach(c -> {
            double utilization = (c.getCurrentExpenditure() / c.getMonthlyLimit()) * 100;
            System.out.printf("%-15s: $%.2f/$%.2f (%.1f%%)%n",
                    c.getName(), c.getCurrentExpenditure(), c.getMonthlyLimit(), utilization);
        });
    }

    private static void exitSystem() {
        System.out.println("\nExiting Budget Manager System. Thank you!");
        scanner.close();
    }
}