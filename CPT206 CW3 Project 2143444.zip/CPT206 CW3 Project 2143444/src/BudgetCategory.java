class BudgetCategory {
    private final String name;
    private final double monthlyLimit;
    private double currentExpenditure;

    public BudgetCategory(String name, double monthlyLimit) {
        this.name = name;
        this.monthlyLimit = monthlyLimit;
        this.currentExpenditure = 0;
    }

    public void addExpense(double amount) throws MonthlyLimitExceededException {
        if (currentExpenditure + amount > monthlyLimit) {
            throw new MonthlyLimitExceededException(
                    "Expense exceeds monthly limit for category [" + name + "]. " +
                            "Current: " + currentExpenditure + ", New: " + amount + ", Limit: " + monthlyLimit);
        }
        currentExpenditure += amount;
    }

    public void resetExpenditure() {
        currentExpenditure = 0;
    }

    public String getName() {
        return name;
    }

    public double getMonthlyLimit() {
        return monthlyLimit;
    }

    public double getCurrentExpenditure() {
        return currentExpenditure;
    }
}